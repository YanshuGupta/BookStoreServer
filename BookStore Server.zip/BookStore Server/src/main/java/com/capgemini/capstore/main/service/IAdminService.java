package com.capgemini.capstore.main.service;

import java.util.List;

import com.capgemini.capstore.main.beans.Admin;
import com.capgemini.capstore.main.exception.EmailAlreadyExistsException;

public interface IAdminService {

	List<Admin> getAllUsers();
	
	Admin createUser(Admin admin) throws EmailAlreadyExistsException;

	Admin deleteUser(int adminId);

	boolean loginUser(String email, String password);
}
