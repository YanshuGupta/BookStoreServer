package com.capgemini.capstore.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Admin;
import com.capgemini.capstore.main.dao.AdminRepository;
import com.capgemini.capstore.main.exception.EmailAlreadyExistsException;
import com.capgemini.capstore.util.MD5;

@Service
public class AdminService implements IAdminService {

	@Autowired
	AdminRepository adminRepository;

	@Override
	public List<Admin> getAllUsers() {

		return adminRepository.findAll();

	}

	@Override
	public Admin createUser(Admin admin) throws EmailAlreadyExistsException {

		if (adminRepository.findByAdminEmail(admin.getAdminEmail()) == null) {

			//admin.setPassword(MD5.encryptText(admin.getPassword()));
			return adminRepository.save(admin);
		}
		throw new EmailAlreadyExistsException("Email Already Exists");
	}

	@Override
	public Admin deleteUser(int adminId) {

		Admin admin = adminRepository.findByAdminId(adminId);
		adminRepository.deleteById(adminId);
		return admin;
	}

	@Override
	public boolean loginUser(String email, String password) {
		Admin admin = adminRepository.findByAdminEmail(email);
		if (admin == null) {
			return false;
		}
		//password = MD5.encryptText(password);
		if (admin.getPassword().equals(password)) {

			return true;
		}

		return false;
	}

}
